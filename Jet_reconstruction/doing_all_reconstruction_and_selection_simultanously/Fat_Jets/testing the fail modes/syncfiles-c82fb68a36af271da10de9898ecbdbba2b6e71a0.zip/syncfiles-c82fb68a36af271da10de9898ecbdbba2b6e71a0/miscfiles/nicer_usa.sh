bold=$(tput bold)
underline=$(tput sgr 0 1)
reset=$(tput sgr0)

purple=$(tput setaf 7)
red=$(tput setaf 1)
green=$(tput setaf 2)
tan=$(tput setaf 3)
blue=$(tput setaf 4)
bluebkg=$(tput setab 21)
redbkg=$(tput setab 1)
whitebkg=$(tput setab 15)

echo ${bluebkg}" ${reset}${bluebkg}${reset}${bluebkg}★${reset}${bluebkg}${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg} ${reset}${redbkg}                                 "${reset}
echo ${bluebkg}"   ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${whitebkg}                                 "${reset}
echo ${bluebkg}" ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg} ${reset}${redbkg}                                 "${reset}
echo ${bluebkg}"   ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${whitebkg}                                 "${reset}
echo ${bluebkg}" ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg} ${reset}${redbkg}                                 "${reset}
echo ${bluebkg}"   ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${whitebkg}                                 "${reset}
echo ${bluebkg}" ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg}  ${reset}${bluebkg}★${reset}${bluebkg} ${reset}${redbkg}                                 "${reset}
echo  ${whitebkg}"                                                   "${reset}
echo  ${redbkg}"                                                   "${reset}
echo  ${whitebkg}"                                                   "${reset}
echo  ${redbkg}"                                                   "${reset}
echo  ${whitebkg}"                                                   "${reset}
echo  ${redbkg}"                                                   "${reset}
